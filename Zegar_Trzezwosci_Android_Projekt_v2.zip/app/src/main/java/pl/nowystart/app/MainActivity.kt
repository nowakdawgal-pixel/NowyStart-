package pl.nowystart.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit

private val Ink = Color(0xFF101820)
private val Panel = Color(0xFF1D2B36)
private val Mint = Color(0xFF7DE0B1)
private val Muted = Color(0xFFA9BAC8)

data class Counter(val id: String = UUID.randomUUID().toString(), val name: String, val since: Long, val bestSince: Long = since)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("zegar_trzezwosci", MODE_PRIVATE)
        setContent {
            var counters by remember { mutableStateOf(loadCounters(prefs.getString("counters", null))) }
            fun persist(next: List<Counter>) {
                counters = next
                val json = JSONArray()
                next.forEach { c -> json.put(JSONObject().apply {
                    put("id", c.id); put("name", c.name); put("since", c.since); put("bestSince", c.bestSince)
                }) }
                prefs.edit().putString("counters", json.toString()).apply()
            }
            NowyStartScreen(counters,
                onAdd = { name, since -> persist(counters + Counter(name = name, since = since)) },
                onReset = { id -> persist(counters.map { if (it.id == id) it.copy(since = System.currentTimeMillis()) else it }) },
                onDelete = { id -> persist(counters.filterNot { it.id == id }) })
        }
    }
}

private fun loadCounters(raw: String?): List<Counter> {
    if (raw.isNullOrBlank()) return listOf(
        Counter(name = "KRYSZTAŁ", since = System.currentTimeMillis()),
        Counter(name = "AMFETAMINA", since = System.currentTimeMillis()),
        Counter(name = "ZIOŁO", since = System.currentTimeMillis()),
        Counter(name = "ALKOHOL", since = System.currentTimeMillis()),
        Counter(name = "PAPIEROSY I (E)PAPIEROSY", since = System.currentTimeMillis())
    )
    return try {
        val a = JSONArray(raw)
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Counter(o.getString("id"), o.getString("name"), o.getLong("since"), o.optLong("bestSince", o.getLong("since")))
        }
    } catch (_: Exception) { emptyList() }
}


private data class RecoveryInfo(val period: String, val body: String, val mind: String)
private fun recoveryTimeline(name: String): List<RecoveryInfo> {
    val n = name.uppercase(Locale("pl", "PL"))
    return when {
        n.contains("PAPIEROS") || n.contains("E-PAPIEROS") -> listOf(
            RecoveryInfo("Pierwsze 24 godziny", "Po rzuceniu papierosów tętno i poziom tlenku węgla mogą wracać w kierunku normy. Przy e-papierosach przebieg zmian jest inny.", "Głód nikotynowy, rozdrażnienie lub trudności z koncentracją mogą się pojawić."),
            RecoveryInfo("2–3 dni", "Organizm usuwa większość nikotyny, jeśli była używana; mogą zmieniać się smak i węch po rzuceniu palenia tytoniu.", "Objawy głodu nikotynowego mogą być silne, ale zwykle z czasem słabną."),
            RecoveryInfo("2–12 tygodni", "Po rzuceniu palenia tytoniu poprawia się krążenie, a aktywność fizyczna może być łatwiejsza.", "Wiele osób zyskuje poczucie sprawczości i większą pewność siebie.")
        )
        n.contains("ALKOHOL") -> listOf(
            RecoveryInfo("Pierwsza doba", "Organizm metabolizuje alkohol. Objawy i tempo poprawy zależą od ilości i częstotliwości picia.", "Mogą wystąpić niepokój, rozdrażnienie lub problemy ze snem."),
            RecoveryInfo("Pierwszy tydzień", "U części osób poprawiają się nawodnienie, apetyt i samopoczucie; sen może nadal być zaburzony.", "Może pojawić się większa jasność myślenia, ale nastrój bywa zmienny."),
            RecoveryInfo("2–4 tygodnie", "U części osób poprawiają się ciśnienie, sen i niektóre parametry metaboliczne.", "Koncentracja i codzienne funkcjonowanie mogą stopniowo się poprawiać.")
        )
        n.contains("ZIOŁO") -> listOf(
            RecoveryInfo("Pierwsze dni", "Po odstawieniu konopi mogą zmieniać się apetyt i sen.", "Możliwe są rozdrażnienie, niepokój, żywe sny i trudności ze snem."),
            RecoveryInfo("1–2 tygodnie", "Objawy odstawienia u wielu osób stopniowo słabną, choć mogą trwać dłużej.", "Nastrój i sen mogą powoli się stabilizować."),
            RecoveryInfo("2–4 tygodnie i dalej", "Dalsze zmiany zależą m.in. od częstotliwości i czasu używania.", "Niektórzy zauważają poprawę koncentracji i pamięci; tempo jest indywidualne.")
        )
        else -> listOf(
            RecoveryInfo("Pierwsze dni", "Po odstawieniu stymulantów możliwe są silne zmęczenie, zwiększony apetyt i zaburzenia snu.", "Może wystąpić obniżony nastrój, lęk lub silny głód substancji."),
            RecoveryInfo("1–2 tygodnie", "Sen i apetyt mogą stopniowo się zmieniać, ale zmęczenie może się utrzymywać.", "U części osób stopniowo poprawia się samopoczucie; głód substancji może powracać."),
            RecoveryInfo("1–3 miesiące i dalej", "Regeneracja przebiega indywidualnie i może wymagać wsparcia specjalisty.", "Koncentracja i codzienne funkcjonowanie mogą poprawiać się stopniowo.")
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NowyStartScreen(counters: List<Counter>, onAdd: (String, Long) -> Unit, onReset: (String) -> Unit, onDelete: (String) -> Unit) {
    var showAdd by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Counter?>(null) }
    var name by remember { mutableStateOf("ALKOHOL") }
    var dateText by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); kotlinx.coroutines.delay(1000) } }
    val longest = counters.maxByOrNull { now - it.since }
    val total = longest?.let { ((now - it.since).coerceAtLeast(0) / 1000) } ?: 0L
    val days = total / 86400
    val hours = (total % 86400) / 3600
    val minutes = (total % 3600) / 60

    MaterialTheme(colorScheme = darkColorScheme(background = Ink, surface = Panel, primary = Mint, onPrimary = Ink, onBackground = Color.White, onSurface = Color.White, secondary = Mint)) {
        Scaffold(containerColor = Ink, floatingActionButton = {
            FloatingActionButton(onClick = { name = ""; dateText = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()); showAdd = true }, containerColor = Mint, contentColor = Ink) {
                Icon(Icons.Default.Add, contentDescription = "Dodaj licznik")
            }
        }) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(top = 20.dp, bottom = 90.dp)) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Spa, null, tint = Mint, modifier = Modifier.size(36.dp))
                        Spacer(Modifier.width(10.dp))
                        Column { Text("ZEGAR TRZEŹWOŚCI", fontSize = 25.sp, fontWeight = FontWeight.Bold); Text("Twój postęp. Twoje tempo.", color = Muted) }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.fillMaxWidth().padding(20.dp)) {
                            Text("TWÓJ NAJDŁUŻSZY AKTUALNY LICZNIK", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(10.dp))
                            Text(if (longest == null) "Zacznij od małego kroku" else "$days dni", color = Mint, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                            Text(if (longest == null) "Dodaj swój pierwszy licznik" else "$hours godz.  $minutes min", fontSize = 18.sp)
                            Text("Każdy dzień ma znaczenie.", color = Muted, modifier = Modifier.padding(top = 8.dp))
                        }
                    }
                }
                item { Text("Twoje liczniki", fontSize = 20.sp, fontWeight = FontWeight.SemiBold) }
                if (counters.isEmpty()) item { Text("Nie masz jeszcze liczników. Dotknij +, aby dodać pierwszy.", color = Muted) }
                items(counters, key = { it.id }) { c ->
                    val sec = ((now - c.since).coerceAtLeast(0) / 1000)
                    val d = sec / 86400; val h = (sec % 86400) / 3600; val m = (sec % 3600) / 60
                    val best = ((now - c.bestSince).coerceAtLeast(0) / 86400)
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(c.name, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                                Text("$d dni • $h godz. • $m min", color = Mint, fontSize = 15.sp)
                                Text("Rekord: $best dni", color = Muted, fontSize = 12.sp)
                                val next = listOf(1L, 7L, 30L, 100L, 365L).firstOrNull { it > d }
                                Text(if (next != null) "Następny kamień milowy: $next dni" else "Kamień milowy: rok i więcej!", color = if (next == null) Mint else Muted, fontSize = 12.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    TextButton(onClick = { selected = c }) { Text("Szczegóły") }
                                }
                            }
                            IconButton(onClick = { onDelete(c.id) }) { Icon(Icons.Default.Delete, "Usuń licznik", tint = Muted) }
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.EmojiEvents, null, tint = Mint, modifier = Modifier.size(30.dp))
                            Spacer(Modifier.width(12.dp))
                            Column { Text("Małe kroki, duże zmiany", fontWeight = FontWeight.SemiBold); Text("Świętuj 1, 7, 30, 100 i 365 dni.", color = Muted, fontSize = 13.sp) }
                        }
                    }
                }
                item { Text("Dane są przechowywane lokalnie na tym urządzeniu. Aplikacja nie zastępuje profesjonalnego wsparcia.", color = Muted, fontSize = 11.sp) }
            }
        }
        if (showAdd) {
            AlertDialog(onDismissRequest = { showAdd = false }, title = { Text("Dodaj licznik") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nazwa, np. Alkohol") }, singleLine = true)
                        OutlinedTextField(value = dateText, onValueChange = { dateText = it }, label = { Text("Data rozpoczęcia (RRRR-MM-DD)") },
                            supportingText = { Text("Wpisz np. 2026-10-01") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii), singleLine = true)
                    }
                },
                confirmButton = { TextButton(onClick = {
                    val parsed = try { SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false }.parse(dateText)?.time } catch (_: Exception) { null }
                    if (name.isNotBlank() && parsed != null && parsed <= System.currentTimeMillis()) { onAdd(name.trim(), parsed); showAdd = false }
                }) { Text("Zapisz") } },
                dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Anuluj") } })
        }
        selected?.let { c ->
            AlertDialog(onDismissRequest = { selected = null }, title = { Text(c.name) },
                text = {
                    Column(Modifier.heightIn(max = 420.dp)) {
                        Text("Licznik rozpoczęty: " + SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("pl", "PL")).format(Date(c.since)))
                        Spacer(Modifier.height(10.dp))
                        Text("POZYTYWNE ZMIANY W ORGANIZMIE I PSYCHICE", color = Mint, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Spacer(Modifier.height(8.dp))
                        recoveryTimeline(c.name).forEach { info ->
                            Text(info.period, fontWeight = FontWeight.Bold, color = Mint)
                            Text("Organizm: " + info.body, fontSize = 13.sp)
                            Text("Psychika: " + info.mind, fontSize = 13.sp)
                            Spacer(Modifier.height(8.dp))
                        }
                        Text("To orientacyjne informacje, nie gwarancja zmian w konkretnym dniu. W razie silnych objawów skontaktuj się z lekarzem.", color = Muted, fontSize = 11.sp)
                    }
                },
                confirmButton = { TextButton(onClick = { onReset(c.id); selected = null }) { Text("Zacznij od dziś") } },
                dismissButton = { TextButton(onClick = { selected = null }) { Text("Zamknij") } })
        }
    }
}
