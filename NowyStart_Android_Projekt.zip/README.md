# Nowy Start — projekt Android MVP

Polskojęzyczna aplikacja Android w Kotlinie i Jetpack Compose.

Funkcje: osobne liczniki z własnymi datami, czas abstynencji, kamienie milowe, rekordy i lokalny zapis w SharedPreferences.

## Jak uruchomić
1. Zainstaluj Android Studio oraz Android SDK 35.
2. Otwórz folder `NowyStart` w Android Studio.
3. Poczekaj na synchronizację Gradle i uruchom aplikację na emulatorze lub telefonie.
4. Aby zbudować APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Wymagane: Android Studio, JDK 17. Ten pakiet zawiera kod źródłowy; APK nie został skompilowany w tym środowisku.

Dane liczników pozostają lokalnie na urządzeniu. Aplikacja nie wymaga konta ani uprawnień internetowych. To narzędzie wspierające, nie zastępuje profesjonalnej pomocy.
